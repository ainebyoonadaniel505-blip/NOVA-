# NOVA TECH COMPANY

A responsive company-profile landing page for **Nova® by AD GROUP OF COMPANIES**.

## Run locally

Open `index.html` in a modern web browser. No build tools or dependencies are required.

## Project files

- `index.html` — page structure and company-profile content
- `styles.css` — responsive visual design and layouts
- `script.js` — mobile navigation and current-year footer

The page uses Google Fonts when available and falls back to system sans-serif fonts. Update the contact email and profile copy in `index.html` with verified company details before publishing.
